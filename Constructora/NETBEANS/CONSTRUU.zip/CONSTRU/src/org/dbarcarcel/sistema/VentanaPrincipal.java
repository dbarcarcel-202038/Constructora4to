/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.dbarcarcel.sistema;
import org.dbarcarcel.vista.Inicio;

/**
 *
 * @author dako
 */
public class VentanaPrincipal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Inicio ventana = new Inicio();
        ventana.setVisible(true);
    }
    
}